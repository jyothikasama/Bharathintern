// Ensure your API key is correctly included
const apiKey = 'c0dbbe2621bf6f7f3c6ae082bc3c6566';

async function getWeather() {
    const city = document.getElementById('cityInput').value || 'London'; // Default to London if no input
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`;

    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error(`City not found: ${response.statusText}`);
        const data = await response.json();

        // Determine the appropriate icon class for the main weather condition
        const iconClass = getWeatherIcon(data.weather[0].main);

        // Update HTML elements with weather data and icon
        document.getElementById('location').innerHTML = 'Location: ' + data.name;
        // Include the icon in the description
        document.getElementById('description').innerHTML = `<i class="${iconClass}"></i> ${data.weather[0].description}`;
        document.getElementById('temp').innerHTML = 'Temperature: ' + data.main.temp + '°C';
        document.getElementById('humidity').innerHTML = 'Humidity: ' + data.main.humidity + '%';
  // Determine the appropriate background color for the main weather condition
    const backgroundColor = getBackgroundColor(data.weather[0].main);

    // Update the body's background color
    document.body.style.backgroundColor = backgroundColor;
    } catch (error) {
        console.error(error);
        alert(error.message);
    }
}

function getBackgroundColor(mainCondition) {
    switch(mainCondition.toLowerCase()) {
        case 'clear':
            return '#FFD700'; // Gold for sunny weather
        case 'clouds':
            return '#C0C0C0'; // Silver for cloudy weather
        case 'rain':
            return '#1F1F7A'; // Dark blue for rainy weather
        case 'snow':
            return '#FFFFFF'; // White for snowy conditions
        // Add more cases for different weather conditions as needed
        default:
            return '#F4F4F4'; // Default background color
    }
}


function getWeatherIcon(mainCondition) {
    switch(mainCondition.toLowerCase()) {
        case 'clear':
            return 'fas fa-sun';
        case 'clouds':
            return 'fas fa-cloud';
        case 'rain':
            return 'fas fa-cloud-rain';
        case 'snow':
            return 'fas fa-snowflake';
        // Add more cases for different weather conditions as needed
        default:
            return 'fas fa-smog';
    }
}
